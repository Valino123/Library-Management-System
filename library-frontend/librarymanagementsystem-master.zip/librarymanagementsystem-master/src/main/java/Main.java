import utils.ConnectConfig;
import utils.DatabaseConnector;
import com.sun.net.httpserver.*;

// import entities.Card;
// import queries.CardList;

// import java.io.BufferedReader;
// import java.io.IOException;
// import java.io.InputStream;
// import java.io.InputStreamReader;
// import java.io.OutputStream;
import java.net.InetSocketAddress;
// import java.util.Map;
import java.util.logging.Logger;

// import com.fasterxml.jackson.databind.ObjectMapper;
// import com.fasterxml.jackson.core.type.TypeReference;


public class Main {

    private static final Logger log = Logger.getLogger(Main.class.getName());

    public static void main(String[] args) {
        try {
            // parse connection config from "resources/application.yaml"
            ConnectConfig conf = new ConnectConfig();
            log.info("Success to parse connect config. " + conf.toString());
            // connect to database
            DatabaseConnector connector = new DatabaseConnector(conf);
            boolean connStatus = connector.connect();
            if (!connStatus) {
                log.severe("Failed to connect database.");
                System.exit(1);
            }
            /* do somethings */
            // create library interfaces instance
            LibraryManagementSystemImpl libImpl = new LibraryManagementSystemImpl(connector);
            // basic block
            // create HTTP server, listen to the port 8000
            HttpServer server = HttpServer.create(new InetSocketAddress(8000), 0);
            //add handler, here bound to /card router
            server.createContext("/card", new CardHandler(libImpl));
            server.createContext("/borrow", new BorrowHandler(libImpl));
            server.createContext("/book", new BookHandler(libImpl));

            // start server
            server.start();
            // mark
            System.out.println("Server is listening on port 8000");
            // keep the server running until it is no longer needed
            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                // release database connection handler
                if (connector.release()) {
                    log.info("Success to release connection.");
                } else {
                    log.warning("Failed to release connection.");
                }
            }));
            /* the shutdown hook is releasing the database connection. 
            This means that when the JVM is shutting down, it will 
            execute the code inside the shutdown hook */

            // // release database connection handler
            // if (connector.release()) {
            //     log.info("Success to release connection.");
            // } else {
            //     log.warning("Failed to release connection.");
            // }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // static class CardHandler implements HttpHandler {
    //     @Override
    //     public void handle(HttpExchange exchange) throws IOException{
    //         // 允许所有域的请求，cors处理, 解决跨域问题
    //         Headers headers = exchange.getResponseHeaders();
    //         headers.add("Access-Control-Allow-Origin", "*");
    //         headers.add("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    //         headers.add("Access-Control-Allow-Headers", "Content-Type");
    //         // 解析请求的方法，看GET还是POST
    //         String requestMethod = exchange.getRequestMethod();
    //         if(requestMethod.equals("GET")){
    //             handleGetRequest(exchange);
    //         }else if(requestMethod.equals("POST")){
    //             handlePostRequest(exchange);
    //         }else if(requestMethod.equals("OPTIONS")){
    //             handleOptionsRequest(exchange);
    //         }else{
    //             exchange.sendResponseHeaders(405, -1);
    //         }

    //     }
    //     private void handleGetRequest(HttpExchange exchange) throws IOException{
    //         //响应头， JSON通信
    //         exchange.getResponseHeaders().set("Content-Type", "application/json");
    //         // 状态码200 ->status ok
    //         exchange.sendResponseHeaders(200, 0);
    //         // 获取输出流
    //         OutputStream outputStream = exchange.getResponseBody();
    //         // 构建JSON响应数据， 这里简化为字符串
    //         //这里写一个固定的JSON，实际可以查表获取数据，然后拼出想要的JSON
    //         CardList cardList = showCards().payload;
    //         String response = "[{\"id\": 1, \"name\": \"John Doe\", \"department\": \"Computer Science\", \"type\": \"Student\"}," +
    //                 "{\"id\": 2, \"name\": \"Jane Smith\", \"department\": \"Electrical Engineering\", \"type\": \"Faculty\"}]";
    //         // 写
    //         outputStream.write(response.getBytes());
    //         // 流一定要close！！！小心泄漏
    //         outputStream.close();         
    //     }
    //     private void handlePostRequest(HttpExchange exchange) throws IOException {
    //         // 读取POST请求体
    //         InputStream requestBody = exchange.getRequestBody();
    //         // 用这个请求体（输入流）构造个buffered reader
    //         BufferedReader reader = new BufferedReader(new InputStreamReader(requestBody));
    //         // 拼字符串的
    //         StringBuilder requestBodyBuilder = new StringBuilder();
    //         // 用来读的
    //         String line;
    //         // 没读完，一直读，拼到string builder里
    //         while ((line = reader.readLine()) != null) {
    //             requestBodyBuilder.append(line);
    //         }

    //         // 看看读到了啥
    //         // Create a new ObjectMapper instance
    //         ObjectMapper mapper = new ObjectMapper();

    //         // Convert the JSON string to a Map
    //         Map<String, String> map = mapper.readValue(requestBodyBuilder.toString(), new TypeReference<Map<String, String>>(){});

    //         // Extract the card details from the map
    //         String name = map.get("name");
    //         String department = map.get("department");
    //         String type = map.get("type");

    //         // Create a new card with the extracted details
    //         // This is just a placeholder, replace it with your actual card creation logic
    //         Card newCard = new Card(name, department, type);

    //         // Add the new card to your data store
    //         // This is just a placeholder, replace it with your actual data store interaction logic
    //         dataStore.add(newCard);
    //         // 实际处理可能会更复杂点
    //         System.out.println("Received POST request to create card with data: " + requestBodyBuilder.toString());

    //         // 响应头
    //         exchange.getResponseHeaders().set("Content-Type", "text/plain");
    //         // 响应状态码200
    //         exchange.sendResponseHeaders(200, 0);

    //         // 剩下三个和GET一样
    //         OutputStream outputStream = exchange.getResponseBody();
    //         outputStream.write("Card created successfully".getBytes());
    //         outputStream.close();
    //     }
    //     private void handleOptionsRequest(HttpExchange exchange) throws IOException {
    //         // 读取POST请求体
    //         InputStream requestBody = exchange.getRequestBody();
    //         // 用这个请求体（输入流）构造个buffered reader
    //         BufferedReader reader = new BufferedReader(new InputStreamReader(requestBody));
    //         // 拼字符串的
    //         StringBuilder requestBodyBuilder = new StringBuilder();
    //         // 用来读的
    //         String line;
    //         // 没读完，一直读，拼到string builder里
    //         while ((line = reader.readLine()) != null) {
    //             requestBodyBuilder.append(line);
    //         }
        
    //         // 看看读到了啥
    //         // 实际处理可能会更复杂点
    //         System.out.println("Received OPTION request :" + requestBodyBuilder.toString());
        
    //         // 响应头
    //         exchange.getResponseHeaders().set("Content-Type", "text/plain");
    //         // 响应状态码200
    //         exchange.sendResponseHeaders(204, 0);
        
    //         // 剩下三个和GET一样
    //         OutputStream outputStream = exchange.getResponseBody();
    //         outputStream.write("Finish options successfully".getBytes());
    //         outputStream.close();
    //     }
    // }

}
